package com.mirabrowser.model

import kotlinx.serialization.Serializable

@Serializable
data class BrowserAction(
    val id: String? = null,
    val action: String,
    val selector: String? = null,
    val value: String? = null,
    val script: String? = null,
    val url: String? = null,
    val x: Int? = null,
    val y: Int? = null,
    val scrollDelta: Int? = null,
    val timeout: Long = 5000L
)

@Serializable
data class BrowserResponse(
    val id: String?,
    val success: Boolean,
    val data: String? = null,
    val error: String? = null
)

enum class ActionType(val value: String) {
    GOTO("goto"),
    CLICK("click"),
    TYPE("type"),
    SCROLL("scroll"),
    SWIPE("swipe"),
    SCREENSHOT("screenshot"),
    EXTRACT_HTML("extract_html"),
    EXECUTE_JS("execute_js"),
    GET_COOKIES("get_cookies"),
    SET_COOKIES("set_cookies")
}
