package com.mirabrowser.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mirabrowser.api.ApiServer
import com.mirabrowser.automation.WebViewBrowserController

class BackgroundAutomationService : Service() {

    private lateinit var apiServer: ApiServer
    private val controller = WebViewBrowserController() // Should be shared

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, createNotification())
        
        // This is a simplified version. In a real app, 
        // the controller should be injected or accessed via a Singleton.
        apiServer = ApiServer(controller)
        apiServer.start(8080)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        apiServer.stop()
        super.onDestroy()
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, "mira_channel")
            .setContentTitle("MiraBrowser Automation Running")
            .setContentText("API Server active on port 8080")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "mira_channel",
                "MiraBrowser Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
