package com.mirabrowser.api

import com.mirabrowser.automation.BrowserController
import com.mirabrowser.model.BrowserAction
import com.mirabrowser.model.BrowserResponse
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import java.time.Duration

class ApiServer(private val controller: BrowserController) {

    private var server: NettyApplicationEngine? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    fun start(port: Int = 8080) {
        server = embeddedServer(Netty, port = port) {
            install(ContentNegotiation) {
                json()
            }
            install(WebSockets) {
                pingPeriod = Duration.ofSeconds(15)
                timeout = Duration.ofSeconds(15)
                maxFrameSize = Long.MAX_VALUE
                masking = false
            }

            routing {
                get("/") {
                    call.respond(mapOf("status" to "MiraBrowser Running", "version" to "1.0.0"))
                }

                post("/execute") {
                    val action = call.receive<BrowserAction>()
                    val response = controller.execute(action)
                    call.respond(response)
                }

                webSocket("/ws") {
                    for (frame in incoming) {
                        frame as? Frame.Text ?:继续
                        val text = frame.readText()
                        try {
                            val action = Json.decodeFromString<BrowserAction>(text)
                            val response = controller.execute(action)
                            send(Frame.Text(Json.encodeToString(response)))
                        } catch (e: Exception) {
                            send(Frame.Text(Json.encodeToString(BrowserResponse(null, false, error = e.message))))
                        }
                    }
                }
            }
        }.start(wait = false)
    }

    fun stop() {
        server?.stop(1000, 5000)
    }
}
