package com.mirabrowser

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.mirabrowser.automation.WebViewBrowserController
import com.mirabrowser.ui.theme.MiraBrowserTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    
    private val controller = WebViewBrowserController()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MiraBrowserTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0A0A0A) // Deep background
                ) {
                    DashboardScreen(controller)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(controller: WebViewBrowserController) {
    var url by remember { mutableStateOf("https://google.com") }
    var logs by remember { mutableStateOf(listOf("MiraBrowser Initialized", "Server active on port 8080")) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Top Bar
        Text(
            "MIRABROWSER ♞",
            style = MaterialTheme.typography.headlineMedium,
            color = Color(0xFF00FFCC), // Cyber Green
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Browser View
        Card(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black)
        ) {
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = WebViewClient()
                        loadUrl(url)
                        controller.setWebView(this)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Logs Panel
        Card(
            modifier = Modifier.height(150.dp).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Text("LIVE LOGS", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                logs.reversed().forEach { log ->
                    Text("> $log", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Basic Controls
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextField(
                value = url,
                onValueChange = { url = it },
                modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color(0xFF222222),
                    focusedIndicatorColor = Color(0xFF00FFCC),
                    unfocusedIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(8.dp)
            )
            Button(
                onClick = { /* Refresh/Go */ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFCC)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("GO", color = Color.Black)
            }
        }
    }
}
