package com.mirabrowser.automation

import android.webkit.WebView
import com.mirabrowser.model.BrowserAction
import com.mirabrowser.model.BrowserResponse
import kotlinx.coroutines.CompletableDeferred

interface BrowserController {
    suspend fun execute(action: BrowserAction): BrowserResponse
    fun setWebView(webView: WebView)
}
