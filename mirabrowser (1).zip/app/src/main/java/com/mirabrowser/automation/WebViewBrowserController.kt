package com.mirabrowser.automation

import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Base64
import android.webkit.ValueCallback
import android.webkit.WebView
import com.mirabrowser.model.BrowserAction
import com.mirabrowser.model.BrowserResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

class WebViewBrowserController : BrowserController {
    private var webView: WebView? = null

    override fun setWebView(webView: WebView) {
        this.webView = webView
    }

    override suspend fun execute(action: BrowserAction): BrowserResponse {
        val wv = webView ?: return BrowserResponse(action.id, false, error = "WebView not initialized")

        return try {
            when (action.action) {
                "goto" -> {
                    withContext(Dispatchers.Main) {
                        wv.loadUrl(action.url ?: "about:blank")
                    }
                    BrowserResponse(action.id, true)
                }
                "click" -> {
                    val result = evaluateJavascript("document.querySelector('${action.selector}').click(); 'success'")
                    BrowserResponse(action.id, result == "\"success\"")
                }
                "type" -> {
                    val result = evaluateJavascript("let el = document.querySelector('${action.selector}'); if(el) { el.value = '${action.value}'; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); 'success' } else { 'error' }")
                    BrowserResponse(action.id, result == "\"success\"")
                }
                "extract_html" -> {
                    val html = evaluateJavascript("document.documentElement.outerHTML")
                    BrowserResponse(action.id, true, data = html)
                }
                "screenshot" -> {
                    val screenshot = takeScreenshot()
                    BrowserResponse(action.id, true, data = screenshot)
                }
                "execute_js" -> {
                    val res = evaluateJavascript(action.script ?: "")
                    BrowserResponse(action.id, true, data = res)
                }
                else -> BrowserResponse(action.id, false, error = "Unknown action: ${action.action}")
            }
        } catch (e: Exception) {
            BrowserResponse(action.id, false, error = e.message)
        }
    }

    private suspend fun evaluateJavascript(script: String): String = suspendCancellableCoroutine { cont ->
        webView?.post {
            webView?.evaluateJavascript(script) { result ->
                if (cont.isActive) cont.resume(result ?: "null")
            }
        }
    }

    private suspend fun takeScreenshot(): String = withContext(Dispatchers.Main) {
        val bitmap = Bitmap.createBitmap(webView!!.width, webView!!.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        webView!!.draw(canvas)
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)
    }
}
