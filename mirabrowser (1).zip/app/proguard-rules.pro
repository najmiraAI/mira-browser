# App-specific ProGuard rules
-keep class com.mirabrowser.model.** { *; }
-keep class io.ktor.** { *; }
-keep class kotlinx.serialization.** { *; }
