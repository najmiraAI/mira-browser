/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { 
  Zap, 
  Layers, 
  Terminal, 
  Cpu, 
  Layout, 
  ShieldCheck,
  ChevronRight,
  Plus
} from "lucide-react";

export default function App() {
  const capabilities = [
    {
      title: "Frontend Modern",
      desc: "Membangun UI responsif dengan React & Tailwind CSS.",
      icon: <Layout className="w-5 h-5 text-blue-500" />,
    },
    {
      title: "Integrasi AI",
      desc: "Menghubungkan aplikasi dengan model Gemini AI.",
      icon: <Cpu className="w-5 h-5 text-purple-500" />,
    },
    {
      title: "Manajemen Data",
      desc: "Mengelola database dan paket npm secara dinamis.",
      icon: <Layers className="w-5 h-5 text-orange-500" />,
    },
    {
      title: "Keamanan Tinggi",
      desc: "Implementasi autentikasi dan otorisasi yang aman.",
      icon: <ShieldCheck className="w-5 h-5 text-green-500" />,
    },
  ];

  return (
    <div className="min-h-screen bg-[#fafafa] text-[#1a1a1a] font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-lg">
            <div className="bg-blue-600 p-1.5 rounded-lg">
              <Terminal className="text-white w-5 h-5" />
            </div>
            <span>AppBuilder<span className="text-blue-600">AI</span></span>
          </div>
          <div className="flex items-center gap-4 text-sm font-medium text-gray-500">
            <a href="#" className="hover:text-blue-600 transition-colors">Dokumentasi</a>
            <button className="bg-black text-white px-4 py-2 rounded-full text-xs font-semibold hover:bg-gray-800 transition-all flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              Proyek Baru
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-16">
        {/* Hero Section */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-xs font-bold mb-6">
              <Zap className="w-3.5 h-3.5 fill-current" />
              SISTEM AKTIF & SIAP
            </div>
            <h1 className="text-6xl font-bold tracking-tight leading-[1.1] mb-6">
              Instal & Bangun <br />
              <span className="text-blue-600 italic">Apapun</span> Di Sini.
            </h1>
            <p className="text-xl text-gray-500 max-w-lg leading-relaxed mb-8">
              Saya adalah asisten pengembang Anda. Saya bisa menginstal paket, 
              merancang antarmuka, dan menghubungkan backend untuk aplikasi Anda secara langsung.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-blue-500/20 flex items-center gap-2">
                Mulai Membangun
                <ChevronRight className="w-4 h-4" />
              </button>
              <button className="px-8 py-4 bg-white border border-gray-200 text-gray-700 font-bold rounded-2xl hover:bg-gray-50 transition-all">
                Lihat Komponen
              </button>
            </div>
          </motion.div>

          {/* Interactive Card Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {capabilities.map((cap, i) => (
              <motion.div
                key={cap.title}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="p-6 bg-white border border-gray-200 rounded-3xl hover:border-blue-400 hover:shadow-xl hover:shadow-blue-500/5 transition-all group cursor-default"
              >
                <div className="mb-4 bg-gray-50 w-10 h-10 rounded-xl flex items-center justify-center group-hover:bg-blue-50 transition-colors">
                  {cap.icon}
                </div>
                <h3 className="font-bold text-lg mb-2">{cap.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">
                  {cap.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Status Section */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-24 p-8 bg-black rounded-[2rem] text-white overflow-hidden relative"
        >
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-2">Siap untuk langkah berikutnya?</h2>
              <p className="text-gray-400">Beritahu saya aplikasi apa yang ingin Anda instal atau buat sekarang.</p>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex -space-x-3">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-black bg-gray-800 flex items-center justify-center text-[10px] font-bold">
                    LIB
                  </div>
                ))}
              </div>
              <div className="text-sm">
                <span className="text-green-400 font-mono">●</span> Sistem Online
              </div>
            </div>
          </div>
          {/* Abstract Background element */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/20 blur-[100px] rounded-full -mr-20 -mt-20"></div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-gray-200 text-sm text-gray-400 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>© 2026 AppBuilder AI. Dibuat dengan cinta untuk Web.</div>
        <div className="flex items-center gap-6">
          <a href="#" className="hover:text-gray-900 transition-colors">Privasi</a>
          <a href="#" className="hover:text-gray-900 transition-colors">Syarat Layanan</a>
          <a href="#" className="hover:text-gray-900 transition-colors">Bantuan</a>
        </div>
      </footer>
    </div>
  );
}

